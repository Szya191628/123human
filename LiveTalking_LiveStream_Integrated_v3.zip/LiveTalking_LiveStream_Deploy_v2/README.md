## LiveStream 源码选择

在 WSL 中，安装、启动和预检脚本会优先使用 `/mnt/d/360download/LiveStream`（对应 Windows 的 `D:\360download\LiveStream`）。如果该目录没有前后端源码，安装脚本会从上游下载到 `workspace/LiveStream`。也可以在 `config/settings.env` 中显式设置 `LIVESTREAM_SOURCE_DIR` 为其他绝对路径。

本包附带 LiveTalking 源码。LiveStream 源码保存在上述本地路径或由安装脚本下载。
# LiveTalking + LiveStream 集成部署包 v2

> **状态：已编写并完成本地静态测试的部署脚本；未在 RTX 3090 真机上执行模型推理/直播/平台推流。**
>
> 本包 **不包含** LiveTalking / LiveStream 上游源码、不包含模型权重、不包含商业授权。
> 第一次执行 `scripts/install.sh` 才会从 GitHub 下载仓库并按上游依赖安装。
> 本包未接入抖音/美团账户，更没有绕过平台直播权限和虚拟人合规审核的功能。

## 1. 最终搭建的系统

```text
LiveStream 管理台 (127.0.0.1:8020)
  ├─ 直播话术循环
  ├─ 知识库 / LLM 问答 (在后台配置供应商 API)
  ├─ 弹幕收集（上游支持的渠道；不同平台需单独适配）
  └─ LiveTalkingClient — HTTP /human + /humanaudio + /sse
             ↓
LiveTalking  (127.0.0.1:8010)
  ├─ Wav2Lip + Avatar
  ├─ TTS 合成语音
  └─ WebRTC 浏览器会话（必须点击“开始连接”建立 sessionid）
             ↓
OBS / 官方直播伴侣 → 具备开播权限的直播平台
```

两者的服务端必须能访问。默认安装于同一台 Linux/WSL2 电脑，配置 URL 为 `http://127.0.0.1:8010`。

**第一版范围**：1 个 Avatar、1 个 WebRTC 数字人 Session、1 个管理后台、1 个 OBS 画面输出。多个平台共用画面属于下一阶段，需要按平台处理推流权限、音轨以及独立弹幕队列，并先核实平台规则。

## 2. 推荐硬件与系统

- Windows 10/11 + NVIDIA RTX 3090 24GB；建议 32GB+ 内存、足够的 SSD 空间。4090 可作为升级选择。
- 推荐 **Ubuntu 22.04/24.04 原生**，也可以 WSL2 Ubuntu，但 WebRTC 在 Windows↔WSL2 网络下存在候选地址/UDP 可达性问题，不能保证浏览器直接连接成功。
- Windows NVIDIA 驱动需支持 WSL2 CUDA；Ubuntu/WSL 中执行 `nvidia-smi` 应识别显卡。**不要在 WSL 内再装 Windows 显卡驱动。**
- **Conda/Miniconda**、Git、Node.js (建议 20+)、npm、Python3、`tmux`。上游两个 Python 环境分别使用 Python 3.12。
- 上游 LiveTalking README 当前参考 PyTorch 2.9.1 / torchvision 0.24.1 / CUDA 12.8 轮子；如驱动不兼容，请对照 [PyTorch 官方历史版本](https://pytorch.org/get-started/previous-versions/) 调整这三个版本以及 wheel index，不要只更换一个包。

**注意**：无论使用本地 RTX 3090 还是云 GPU，都需要 GPU 算力，购买 LiveTalking Windows 商业整合包不一定包含算力。

## 3. Windows + WSL2 的操作步骤

### 3.1 准备 WSL2

以 Windows 管理员身份运行 PowerShell（若已安装 Ubuntu 则跳过安装）：

```powershell
wsl --install -d Ubuntu
wsl --update
```

重启电脑并进入 Ubuntu，完成 Linux 账户创建。执行：

```bash
sudo apt update
sudo apt install -y git curl unzip ffmpeg tmux build-essential python3 python3-venv
nvidia-smi
```

安装 Linux 版 Miniconda，并确认：`conda --version`。安装 Node.js/npm（建议 Node 20 或以上），确认：`node --version && npm --version`。

可以用 Windows 的“检查Windows显卡.bat”先检查显卡，但 **Windows 能看到显卡 ≠ WSL2 内的 PyTorch 一定能调用 CUDA**。

### 3.2 解压与安装

建议解压到 Ubuntu 的 `~/LiveTalking_LiveStream_Deploy_v2`，**不要**直接在 `/mnt/c` 或 `/mnt/d` 下运行大型模型（可能产生严重 I/O 性能问题）。

例如，你把 ZIP 放在 Windows 下载目录 `C:\Users\你的用户名\Downloads`，则在 WSL2 Ubuntu 中执行：

```bash
cd ~
unzip "/mnt/c/Users/你的用户名/Downloads/LiveTalking_LiveStream_Deploy_v2.zip"
cd ~/LiveTalking_LiveStream_Deploy_v2
cp config/settings.env.example config/settings.env
```

如果这个 ZIP 是解压为文件夹，目录名应为 `LiveTalking_LiveStream_Deploy_v2`。

先下载 Git 仓库（检查 GitHub 网络是否通畅）：

```bash
bash scripts/install.sh --clone-only
```

再安装两个 Conda 环境、官方依赖并构建 Vue 管理前端：

```bash
bash scripts/install.sh
```

安装脚本遵循上游 README；首次下载 CUDA PyTorch 和其他库体积较大。不会自动执行 `git pull`，从而避免静默覆盖已修改的上游代码。运行后把两个仓库的 Commit SHA 写入 `UPSTREAM_COMMITS.txt` 便于复现。

**当前仓库如果变更导致依赖冲突，请记录错误日志，并根据上游最新 README 处理；本部署包无法保证跨未来版本的 API 兼容。**

### 3.3 下载模型与 Avatar（必做）

**官方模型下载地址**：

- [夸克云盘](https://pan.quark.cn/s/83a750323ef0)
- [Google Drive](https://drive.google.com/drive/folders/1FOC_MD6wdogyyX_7V1d4NDIO7P9NlSAJ?usp=sharing)

按官方说明放置：

```text
workspace/
  LiveTalking/
    models/wav2lip.pth       ← 下载 wav2lip256.pth 后重命名
    data/avatars/wav2lip256_avatar1/ ← 解压 wav2lip256_avatar1.tar.gz
  LiveStream/
    backend/
    frontend/dist/           ← npm run build 生成
```

注意：目录层级必须正确，不能解压成 `.../wav2lip256_avatar1/wav2lip256_avatar1/`。

默认 `config/settings.env` 选择 `MODEL=wav2lip`。后续可切换 MuseTalk，但要按上游官方要求下载 MuseTalk 权重与形象数据，不能直接复用 Wav2Lip 的 Avatar。

### 3.4 预检

```bash
python3 scripts/doctor.py --torch
```

应重点看：Git、Conda、npm、LiveTalking 源码、LiveStream 源码、LiveStream 前端、Wav2Lip 权重、Avatar、GPU、PyTorch CUDA。

`WARN` 表示还没准备好，不能据此认为“数字人已经可以直播”。在安装前运行 `doctor.py` 用于确认缺什么。

### 3.5 启动服务（推荐两终端联调）

在 **终端 A**：

```bash
bash scripts/start-livetalking.sh
```

在 **终端 B**：

```bash
bash scripts/start-livestream.sh
```

之后在 Windows 浏览器中打开：

- **LiveTalking**：http://127.0.0.1:8010/index.html
- **LiveStream**：http://127.0.0.1:8020

先打开 LiveTalking 页面，点击 **开始连接**，等待数字人画面出现。这里产生的 `sessionid` 是 LiveStream 后续播放内容的目标 Session。

然后进入 LiveStream 的 **系统配置**：

1. 将 LiveTalking 服务器地址填写 `http://127.0.0.1:8010`，保存（上游当前配置写入 SQLite DB，并在重启后生效）。
2. 配置你自己的 LLM API Key、模型与 Base URL；如果不需要智能问答，可以先测试纯话术循环。`LiveStream` 的 LLM 等参数在 **网页系统配置** 中维护，不是本包的 settings.env。
3. 添加一组经过核实的商品话术，例如 `examples/直播话术示例.txt`。
4. 在 **直播控制** 中选择真实存在的 `sessionid`，选择上游支持的直播平台，再点击开始。
5. 通过 OBS 窗口/浏览器源采集数字人画面与音轨，在符合平台政策、已获开播权限的前提下推流。

查看已连接 Session：

```bash
python3 scripts/test-session.py --list
```

仅在你确定播放目标后，发送一次测试讲话：

```bash
python3 scripts/test-session.py --send --sessionid "这里填真实SessionID" --text "欢迎来到数字人直播间！"
```

再次检查：

```bash
python3 scripts/doctor.py --live --torch
```

### 3.6 后台启动、查看状态、日志和停止

首次排错建议两个终端手工启动。配置完成并跑通以后才使用后台运行：

```bash
bash scripts/start-all.sh       # tmux 创建两个独立会话
bash scripts/status.sh          # 检查会话及实际 HTTP API
bash scripts/logs.sh both       # 查看两边日志，Ctrl+C 只退出日志查看
bash scripts/logs.sh lt         # 只看 LiveTalking
bash scripts/logs.sh ls         # 只看 LiveStream
bash scripts/stop-all.sh        # 停止两个后台 tmux 会话
```

`start-all.sh` **不会**自动建立 WebRTC Session、自动授权抖音/美团、开播或无人值守恢复断线。Windows/WSL 睡眠或关机后服务会停止。生产部署需要 systemd/容器编排、健康检查重启策略、显卡监测、SLA、平台授权和人工接管。

### 3.7 Windows 小工具

`windows/检查Windows显卡.bat`：在 Windows 命令提示符查看 `nvidia-smi`。

`windows/打开部署终端.bat`：默认假设 WSL 发行版叫 `Ubuntu` 且项目放 `~/LiveTalking_LiveStream_Deploy_v2`，启动前请先确认这些路径，不匹配时修改 bat 文件。推荐直接在 Ubuntu 终端执行上述脚本。

## 4. OBS 的正确接入

**方案 A：WebRTC + OBS 窗口采集（推荐第一阶段）**

1. 在 LiveTalking 网页中建立 WebRTC Session，必须同时看到人物动作和听到声音。
2. 在 OBS 里添加“窗口采集”或“显示器采集”，裁切网页多余按钮；检查桌面音频/应用音频捕获以避免静音。
3. 在 OBS 设置视频分辨率和帧率，先本地录制并回放 10~30 分钟，检查音画同步、GPU 占用、内存泄露和异常退出。
4. 开播需要在直播平台或直播伴侣中取得合法的推流方式/权限。**不要把获取推流地址等同于平台允许自动无人直播。**

**方案 B：Virtual Camera**

上游支持 `--transport virtualcam`，但 Linux 虚拟摄像头 (`v4l2loopback`) **不会自动变成 Windows OBS 的虚拟摄像头**。在 WSL2 尤其容易卡住，因此当前默认 WebRTC。需要虚拟摄像头时优先用原生 Windows 商业客户端或原生 Linux 环境验证音视频设备。

## 5. 抖音 + 美团同时直播

目前交付的是 **单路 LiveTalking 数字人 → LiveStream 管理 → OBS** 的集成部署底座；**不是已获得抖音、美团开播授权的多平台全自动直播产品**。

如果未来要多个平台同时运行，有两种技术方向：

- **共用同一画面**：单个数字人画面通过被平台允许的推流管线分别输出；需要处理双平台的推流协议/带宽和授权问题。不要把两边评论混在一个口播队列里。
- **各平台独立话术和互动**：至少要各自管理 Session、商品知识库、评论队列和账号权限；GPU 并发帧率要做现场压测，不能因为 3090 有 24GB 就保证能同时跑多路。

**合规重点**：平台是否允许虚拟数字人主持、是否需要实名或标识、是否允许无人值守与自动互动，以及商家服务的第三方推流 API 是否开放，均应取得平台官方确认。

## 6. 故障排查

| 现象 | 首先排查 |
|---|---|
| `nvidia-smi` 在 WSL 中不存在 | Windows NVIDIA 驱动版本、WSL2 GPU 映射、WSL 更新 |
| `torch.cuda.is_available() == False` | CUDA wheel 与驱动兼容性、环境是不是 `livetalking` |
| 缺少 `wav2lip.pth` | 模型是否下载并重命名到 `workspace/LiveTalking/models/` |
| Avatar not found | Avatar 是否解压在 `data/avatars/<AVATAR_ID>` |
| `8020` 返回 404 | 前端 `npm run build` 是否成功产生 `frontend/dist/index.html` |
| 网页打开但数字人黑屏 | WebRTC ICE candidate 与 WSL UDP/NAT、浏览器权限、渲染日志 |
| LiveStream 找不到 Session | 先打开 `8010/index.html` 点开始连接，再调用 `/api/admin/sessions` |
| 后台设置了 LiveTalking URL 仍失败 | 配置变更是否已重启 LiveStream，后端是否连接到正确的 8010 地址 |
| 启动后立刻退出 | 查看 `logs/livetalking.log` 和 `logs/livestream.log` |
| OBS 无声音 | 检查网页是否发出音频、OBS 是否正确采集应用音频、是否重复采集导致回声 |

## 7. 成本、安全、授权

- 使用本地 GPU，避免租用云 GPU；但存在电费与硬件折旧。
- EdgeTTS 和远程 LLM 可能依赖网络或第三方计费/条款；**本包不提供免费无限量的 AI API**。
- LiveTalking 源码为 Apache-2.0，**不代表其所用的每个预训练模型/声音/头像均可商用**。原始 Wav2Lip 模型有非商业使用限制；商用前确认许可证或取得相应授权。
- LiveStream 的公开仓库许可情况请自行向作者核实，不应仅凭 GitHub 可见源码推断可随意闭源商用。
- 两个上游项目 API 及 LiveStream 管理后台可能缺乏生产级鉴权，当前部署将 LiveStream 限制在 `127.0.0.1`。LiveTalking 上游会监听 `0.0.0.0:8010`；务必通过 Windows 防火墙/WSL 防火墙控制访问。**严禁无认证直接暴露到公网**。
- 商业带货时，先解决数字人头像/声音肖像权、版权授权、商品宣传真实性与平台规则。

## 8. 验收清单

- [ ] WSL 内 `nvidia-smi` 显示 RTX 3090 及驱动。
- [ ] `python3 scripts/doctor.py --torch` 所需项均 PASS。
- [ ] `8010` 打开页面，WebRTC 可以成功连接，有视频、有音频。
- [ ] `python3 scripts/test-session.py --list` 显示有效的 Session。
- [ ] `--send` 测试话术后，数字人准确读出并且口型同步。
- [ ] LiveStream `8020` 可以登录/访问（默认上游可能无登录）、配置 API、保存话术。
- [ ] LiveStream 选择 Session 后话术循环，手动打断和停止有效。
- [ ] OBS 本地录制 30 分钟，回放无明显音画不同步。
- [ ] 如果要开商业直播，已确认所有组件授权、平台资质与标识要求。

## 9. 相关官方源码与文档

- [LiveTalking GitHub](https://github.com/lipku/LiveTalking)
- [LiveTalking 官方 README](https://github.com/lipku/LiveTalking/blob/main/README.md)
- [LiveTalking API 文档](https://github.com/lipku/LiveTalking/blob/main/docs/api.md)
- [LiveStream GitHub](https://github.com/lipku/LiveStream)
- [LiveTalking 使用手册](https://doc.livetalking.ai/docs/usage/)

## 10. 验证说明

部署包自带的测试只验证 Python / Shell 文件语法、存在性、CLI 参数校验以及基本流程入口：

```bash
python3 -m unittest discover -s tests -v
```

上游源码、GPU、模型权重、真实直播平台接入 **需在你的 RTX 3090 电脑上进一步验证**。不要误将本包静态测试 PASS 理解为直播端到端通过。
