@echo off
chcp 65001 >nul
REM 此文件假设项目位于 WSL2 Ubuntu 的 ~/LiveTalking_LiveStream_Deploy_v2
REM 如果你改了目录，请修改下面一行的 cd 路径。
wsl.exe -d Ubuntu -- bash -lc "cd ~/LiveTalking_LiveStream_Deploy_v2 && python3 scripts/doctor.py && bash scripts/start-all.sh && bash scripts/status.sh; exec bash"
pause
